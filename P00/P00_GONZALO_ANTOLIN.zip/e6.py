from Seq0 import*

gene = "U5"
filename = "sequences/U5.txt"
sequence = seq_read_fasta(filename)

fragment = sequence[:20]
reverse = seq_reverse(sequence, 20)

print(f"Gene {gene}")
print("Fragment: ", fragment)
print("Reverse: ", reverse)